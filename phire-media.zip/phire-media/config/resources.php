<?php

return [
    'media' => [
        'index',
        'add',
        'batch',
        'ajax',
        'edit',
        'remove',
        'browser'
    ],
    'media-libraries' => [
        'index',
        'add',
        'edit',
        'process'
    ]
];