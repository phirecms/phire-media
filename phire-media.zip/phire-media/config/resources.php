<?php

return [
    'media' => [
        'index',
        'add',
        'batch',
        'edit',
        'remove',
        'browser'
    ],
    'media-libraries' => [
        'index',
        'add',
        'edit',
        'process'
    ]
];