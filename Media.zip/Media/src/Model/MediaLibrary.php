<?php

namespace Media\Model;

use Phire\Model\AbstractModel;
use Media\Table;

class MediaLibrary extends AbstractModel
{

}
