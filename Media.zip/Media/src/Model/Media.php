<?php

namespace Media\Model;

use Media\Table;
use Phire\Model\AbstractModel;

class Media extends AbstractModel
{

}
