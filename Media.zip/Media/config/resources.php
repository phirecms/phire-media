<?php

return [
    'media' => [
        'index',
        'add',
        'edit',
        'remove'
    ],
    'media-library' => [
        'index',
        'add',
        'edit',
        'remove'
    ]
];