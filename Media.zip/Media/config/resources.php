<?php

return [
    'media' => [
        'index',
        'add',
        'edit',
        'remove'
    ],
    'media-libraries' => [
        'index',
        'add',
        'edit',
        'remove'
    ]
];