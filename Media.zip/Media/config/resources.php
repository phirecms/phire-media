<?php

return [
    'media' => [
        'index',
        'add',
        'batch',
        'edit',
        'remove'
    ],
    'media-libraries' => [
        'index',
        'add',
        'edit',
        'remove'
    ]
];