--
-- Media Module PostgreSQL Database for Phire CMS 2.0
--

-- --------------------------------------------------------
