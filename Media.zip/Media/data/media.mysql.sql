--
-- Media Module MySQL Database for Phire CMS 2.0
--

-- --------------------------------------------------------
SET FOREIGN_KEY_CHECKS = 0;

SET FOREIGN_KEY_CHECKS = 1;
